<?php get_header(); ?>

	<?php while ( have_posts() ) : the_post(); ?>

	<?php wp_list_authors(); ?>

		<div class="page">
			<div class="limit">
				<div class="inner">
					
					<div class="content">
						<h1><?php the_author() ?></h1>			
						<?php the_content() ?>
					</div>

				</div>
			</div>
		</div>

	<?php endwhile; ?>

<?php get_footer(); ?>